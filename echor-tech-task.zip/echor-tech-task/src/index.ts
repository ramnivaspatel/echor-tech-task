import express, { Request, Response } from 'express';
import cors from 'cors';

const app = express();
app.use(express.json());
app.use(cors());

type TransformInput = { sentence?: string };

function tokenize(sentence: string): string[] {
  // Split on whitespace, keep punctuation attached (so Node.js remains 'Node.js')
  return sentence.trim().split(/\s+/).filter(Boolean);
}

function uniqueLowercase(words: string[]): string[] {
  const seen = new Set<string>();
  const result: string[] = [];
  for (const w of words) {
    const lw = w.toLowerCase();
    if (!seen.has(lw)) {
      seen.add(lw);
      result.push(lw);
    }
  }
  return result;
}

app.post('/api/transform', (req: Request<{}, {}, TransformInput>, res: Response) => {
  const { sentence } = req.body;

  if (typeof sentence !== 'string' || sentence.trim().length === 0) {
    return res.status(400).json({ error: 'sentence is required and must be a non-empty string' });
  }

  const words = tokenize(sentence);
  const word_count = words.length;
  const unique_words = uniqueLowercase(words);
  const reversed_sentence = words.slice().reverse().join(' ');

  return res.json({ word_count, unique_words, reversed_sentence });
});

const PORT = process.env.PORT ? Number(process.env.PORT) : 3000;
app.listen(PORT, () => {
  console.log(`Server listening on port ${PORT}`);
});
